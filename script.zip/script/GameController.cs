using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameController : MonoBehaviour
{
    public DestroyOnContact destroyOnContact;

    public float xMinMax;
    public float zMin;
    public float count;
    public float startWait;
    public float cloneWait;

    public GameObject rock;


    private void Start()
    {
;       StartCoroutine(Waves());
    }
    IEnumerator Waves()
    {
        while (true)
        {
            yield return new WaitForSeconds(1);
            for (int i = 0; i < count; i++)
            {
                Instantiate(rock, new Vector3(Random.Range(-xMinMax, xMinMax), 0, zMin), Quaternion.identity);
                yield return new WaitForSeconds(cloneWait);
            }
            yield return new WaitForSeconds(startWait);
        }
        
    }
}
